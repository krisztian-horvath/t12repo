import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {
  
  primE:number=1;

  PrimE(primE:number):string {
    let prim:boolean=true;
    for (let i = 2; i < primE/2; i++) {
      if (primE % i == 0) {
        prim=false;
      }
    }
    if (prim==true) {
      return `A ${primE} prím szám.`;
    } else {
      return `A ${primE} NEM prím szám.`;
    }
  }

  eredmenyLista:string[]=[];

  EredmenyMentes():void {
    this.eredmenyLista.push(`${this.PrimE(this.primE)}`)
  }
}
