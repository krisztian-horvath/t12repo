import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {
  kozHom1: number=0;
  kozHom2: number=0;
  kozHom3: number=0;

  eredmeny: string = "";

  aktualisRiadoSzint(): void {
    if (this.kozHom1 > 27 && this.kozHom2 > 27 && this.kozHom3 > 27) {
      this.eredmeny = `Az aktuális hőségriadó szintje: 3. szintű`;
      this.korabbiEredmenyek.push(`${this.kozHom1},${this.kozHom2} és ${this.kozHom3} esetén 3. szintű hőségriadó volt elrendelve`);
    } else if (this.kozHom1 > 25 && this.kozHom2 > 25 && this.kozHom3 > 25) {
      this.eredmeny = `Az aktuális hőségriadó szintje: 2. szintű`;
      this.korabbiEredmenyek.push(`${this.kozHom1},${this.kozHom2} és ${this.kozHom3} esetén 2. szintű hőségriadó volt elrendelve`);
    } else if (this.kozHom1 > 25 || this.kozHom2 > 25 || this.kozHom3 > 25) {
      this.eredmeny = `Az aktuális hőségriadó szintje: 1. szintű`;
      this.korabbiEredmenyek.push(`${this.kozHom1},${this.kozHom2} és ${this.kozHom3} esetén 1. szintű hőségriadó volt elrendelve`);
    } else {
      this.eredmeny = `Nincs hőségriadó`
    }
  }

  korabbiEredmenyek: string[] = []
}
